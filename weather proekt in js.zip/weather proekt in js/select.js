const myFunction = (e) =>{
    let btn = document.querySelectorAll("button")
    let value = e.target.value;



    for(let i = 0; i<btn.length; i++){
        if(i!=4){
            btn[i].style.backgroundColor = value
        btn[i].innerHTML = value
        }else {
          

        }
        
      
    }      












}
